<?php
/**
 * Plugin Name: ISC Phrase API
 * Description: API-only layer for Intention Space phrase collection: spaces, phrases, SR classification, normalization, and export endpoints.
 * Version: 0.2.0
 * Author: IntentixLab
 */

if (!defined('ABSPATH')) {
    exit;
}

class ISC_Phrase_API {
    const VERSION = '0.2.0';
    const SPACE_TABLE = 'isc_spaces';
    const PHRASE_TABLE = 'isc_phrases';
    const CLUSTER_TABLE = 'isc_phrase_clusters';

    public static function init() {
        register_activation_hook(__FILE__, [__CLASS__, 'activate']);
        add_action('plugins_loaded', [__CLASS__, 'maybe_upgrade']);
        add_action('rest_api_init', [__CLASS__, 'register_routes']);
        add_action('rest_api_init', [__CLASS__, 'cors_headers'], 15);
    }

    public static function table($name) {
        global $wpdb;
        return $wpdb->prefix . $name;
    }

    public static function activate() {
        self::create_or_update_tables();
        self::ensure_default_space();
        update_option('isc_phrase_api_version', self::VERSION);
    }

    public static function maybe_upgrade() {
        $current = get_option('isc_phrase_api_version');
        if ($current !== self::VERSION) {
            self::create_or_update_tables();
            self::ensure_default_space();
            update_option('isc_phrase_api_version', self::VERSION);
        }
    }

    private static function create_or_update_tables() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();

        $spaces = self::table(self::SPACE_TABLE);
        $phrases = self::table(self::PHRASE_TABLE);
        $clusters = self::table(self::CLUSTER_TABLE);

        $sql_spaces = "CREATE TABLE $spaces (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            space_uid VARCHAR(120) NOT NULL,
            title VARCHAR(190) NOT NULL,
            description TEXT NULL,
            owner_user_id BIGINT UNSIGNED NULL,
            owner_email VARCHAR(190) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY space_uid (space_uid),
            KEY owner_user_id (owner_user_id)
        ) $charset;";

        $sql_clusters = "CREATE TABLE $clusters (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            normalized_id VARCHAR(120) NOT NULL,
            normalized_phrase TEXT NOT NULL,
            description TEXT NULL,
            created_by BIGINT UNSIGNED NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY normalized_id (normalized_id)
        ) $charset;";

        $sql_phrases = "CREATE TABLE $phrases (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            space_id BIGINT UNSIGNED NULL,
            phrase TEXT NOT NULL,
            context TEXT NULL,
            source VARCHAR(120) NULL,
            owner_user_id BIGINT UNSIGNED NULL,
            owner_email VARCHAR(190) NULL,
            cluster_id BIGINT UNSIGNED NULL,
            sr_type VARCHAR(60) NOT NULL DEFAULT 'unclassified',
            execution_potential VARCHAR(40) NOT NULL DEFAULT 'unknown',
            isc_role VARCHAR(40) NOT NULL DEFAULT 'unclassified',
            status VARCHAR(30) NOT NULL DEFAULT 'new',
            admin_note TEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY space_id (space_id),
            KEY owner_user_id (owner_user_id),
            KEY cluster_id (cluster_id),
            KEY sr_type (sr_type),
            KEY execution_potential (execution_potential),
            KEY isc_role (isc_role),
            KEY status (status),
            KEY created_at (created_at)
        ) $charset;";

        dbDelta($sql_spaces);
        dbDelta($sql_clusters);
        dbDelta($sql_phrases);

        self::ensure_column($phrases, 'sr_type', "VARCHAR(60) NOT NULL DEFAULT 'unclassified'");
        self::ensure_column($phrases, 'execution_potential', "VARCHAR(40) NOT NULL DEFAULT 'unknown'");
    }

    private static function ensure_column($table, $column, $definition) {
        global $wpdb;
        $exists = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM $table LIKE %s", $column));
        if (!$exists) {
            $wpdb->query("ALTER TABLE $table ADD COLUMN $column $definition");
        }
    }

    private static function ensure_default_space() {
        global $wpdb;
        $table = self::table(self::SPACE_TABLE);

        $existing = $wpdb->get_var(
            $wpdb->prepare("SELECT id FROM $table WHERE space_uid = %s", 'default_cloud_phrases')
        );

        if (!$existing) {
            $now = current_time('mysql');
            $wpdb->insert($table, [
                'space_uid' => 'default_cloud_phrases',
                'title' => 'Default Cloud Phrase Space',
                'description' => 'Default Intention Space instance for collected cloud architecture phrases.',
                'owner_user_id' => null,
                'owner_email' => null,
                'created_at' => $now,
                'updated_at' => $now,
            ], ['%s','%s','%s','%d','%s','%s','%s']);
        }
    }

    public static function cors_headers() {
        add_filter('rest_pre_serve_request', function ($served, $result, $request, $server) {
            $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';

            $allowed_origins = [
                'https://intentixlab.com',
                'https://www.intentixlab.com',
                'https://keybytesystems.com',
                'https://www.keybytesystems.com'
            ];

            if (in_array($origin, $allowed_origins, true)) {
                header('Access-Control-Allow-Origin: ' . esc_url_raw($origin));
                header('Access-Control-Allow-Credentials: true');
                header('Access-Control-Allow-Methods: GET, POST, PUT, OPTIONS');
                header('Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce');
            }

            return $served;
        }, 10, 4);
    }

    public static function register_routes() {
        register_rest_route('isc/v1', '/health', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'health'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route('isc/v1', '/me', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'me'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route('isc/v1', '/schema', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'schema'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route('isc/v1', '/spaces', [
            [
                'methods' => 'GET',
                'callback' => [__CLASS__, 'get_spaces'],
                'permission_callback' => '__return_true'
            ],
            [
                'methods' => 'POST',
                'callback' => [__CLASS__, 'create_space'],
                'permission_callback' => [__CLASS__, 'must_be_logged_in']
            ]
        ]);

        register_rest_route('isc/v1', '/phrases', [
            [
                'methods' => 'GET',
                'callback' => [__CLASS__, 'get_phrases'],
                'permission_callback' => '__return_true'
            ],
            [
                'methods' => 'POST',
                'callback' => [__CLASS__, 'create_phrase'],
                'permission_callback' => [__CLASS__, 'must_be_logged_in']
            ]
        ]);

        register_rest_route('isc/v1', '/phrases/(?P<id>\d+)', [
            'methods' => 'PUT',
            'callback' => [__CLASS__, 'update_phrase'],
            'permission_callback' => [__CLASS__, 'must_be_admin']
        ]);

        register_rest_route('isc/v1', '/export-space', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'export_space'],
            'permission_callback' => '__return_true'
        ]);
    }

    public static function must_be_logged_in() {
        return is_user_logged_in();
    }

    public static function must_be_admin() {
        return current_user_can('manage_options');
    }

    public static function sr_type_options() {
        return [
            'unclassified',
            'action_phrase',
            'constraint_phrase',
            'resource_phrase',
            'service_phrase',
            'decision_phrase',
            'actor_phrase',
            'state_phrase',
            'risk_phrase',
            'cost_phrase',
            'location_phrase',
            'network_phrase',
            'data_phrase',
            'observability_phrase'
        ];
    }

    public static function execution_potential_options() {
        return [
            'unknown',
            'active',
            'passive',
            'interpretive',
            'external_capability',
            'field_condition'
        ];
    }

    public static function isc_role_options() {
        return [
            'unclassified',
            'intention',
            'design_node',
            'object',
            'pulse',
            'signal',
            'cpux',
            'constraint',
            'service',
            'resource',
            'decision_phrase'
        ];
    }

    public static function clean_enum($value, $allowed, $fallback) {
        $value = sanitize_key($value ?: $fallback);
        return in_array($value, $allowed, true) ? $value : $fallback;
    }

    public static function health() {
        return [
            'status' => 'ok',
            'plugin' => 'ISC Phrase API',
            'version' => self::VERSION
        ];
    }

    public static function schema() {
        return [
            'sr_types' => self::sr_type_options(),
            'execution_potentials' => self::execution_potential_options(),
            'isc_roles' => self::isc_role_options(),
            'principle' => 'A phrase is first classified at the Situational Reality layer, then optionally mapped to Intention Space runtime roles.'
        ];
    }

    public static function me() {
        if (!is_user_logged_in()) {
            return [
                'logged_in' => false,
                'login_url' => wp_login_url(),
                'register_url' => wp_registration_url()
            ];
        }

        $user = wp_get_current_user();

        return [
            'logged_in' => true,
            'user' => [
                'id' => $user->ID,
                'email' => $user->user_email,
                'display_name' => $user->display_name,
                'roles' => $user->roles
            ]
        ];
    }

    public static function get_spaces($request) {
        global $wpdb;
        self::ensure_default_space();

        $table = self::table(self::SPACE_TABLE);
        $rows = $wpdb->get_results("
            SELECT id, space_uid, title, description, owner_email, created_at, updated_at
            FROM $table
            ORDER BY created_at DESC
        ", ARRAY_A);

        return ['spaces' => $rows];
    }

    public static function create_space($request) {
        global $wpdb;

        $space_uid = sanitize_key($request->get_param('space_uid'));
        $title = sanitize_text_field($request->get_param('title'));
        $description = sanitize_textarea_field($request->get_param('description') ?: '');

        if (!$space_uid || !$title) {
            return new WP_Error('isc_missing_fields', 'space_uid and title are required.', ['status' => 400]);
        }

        $table = self::table(self::SPACE_TABLE);

        $existing = $wpdb->get_row(
            $wpdb->prepare("SELECT id, space_uid, title FROM $table WHERE space_uid = %s", $space_uid),
            ARRAY_A
        );

        if ($existing) {
            return new WP_Error('isc_space_exists', 'A space with this space_uid already exists.', ['status' => 409]);
        }

        $user = wp_get_current_user();
        $now = current_time('mysql');

        $ok = $wpdb->insert($table, [
            'space_uid' => $space_uid,
            'title' => $title,
            'description' => $description,
            'owner_user_id' => $user->ID,
            'owner_email' => $user->user_email,
            'created_at' => $now,
            'updated_at' => $now
        ], ['%s','%s','%s','%d','%s','%s','%s']);

        if (!$ok) {
            return new WP_Error('isc_db_error', 'Could not create space.', ['status' => 500]);
        }

        return [
            'status' => 'ok',
            'space' => [
                'id' => intval($wpdb->insert_id),
                'space_uid' => $space_uid,
                'title' => $title,
                'description' => $description
            ]
        ];
    }

    public static function get_phrases($request) {
        global $wpdb;

        $space_uid = sanitize_key($request->get_param('space_uid'));
        $limit = intval($request->get_param('limit') ?: 100);
        $limit = max(1, min($limit, 500));

        $phrases = self::table(self::PHRASE_TABLE);
        $spaces = self::table(self::SPACE_TABLE);
        $clusters = self::table(self::CLUSTER_TABLE);

        $params = [];
        $where = '';

        if ($space_uid) {
            $where = "WHERE s.space_uid = %s";
            $params[] = $space_uid;
        }

        $sql = "
            SELECT
                p.id, p.space_id, s.space_uid, s.title AS space_title,
                p.phrase, p.context, p.source,
                p.owner_email,
                p.sr_type, p.execution_potential,
                p.isc_role, p.status,
                p.admin_note,
                c.normalized_id, c.normalized_phrase,
                p.created_at, p.updated_at
            FROM $phrases p
            LEFT JOIN $spaces s ON p.space_id = s.id
            LEFT JOIN $clusters c ON p.cluster_id = c.id
            $where
            ORDER BY p.created_at DESC
            LIMIT %d
        ";

        $params[] = $limit;
        $rows = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);

        return ['phrases' => $rows];
    }

    public static function create_phrase($request) {
        global $wpdb;

        $space_id = intval($request->get_param('space_id'));
        $space_uid = sanitize_key($request->get_param('space_uid'));
        $phrase = sanitize_textarea_field($request->get_param('phrase'));
        $context = sanitize_textarea_field($request->get_param('context') ?: '');
        $source = sanitize_text_field($request->get_param('source') ?: 'api');

        $sr_type = self::clean_enum(
            $request->get_param('sr_type'),
            self::sr_type_options(),
            'unclassified'
        );

        $execution_potential = self::clean_enum(
            $request->get_param('execution_potential'),
            self::execution_potential_options(),
            'unknown'
        );

        $isc_role = self::clean_enum(
            $request->get_param('isc_role'),
            self::isc_role_options(),
            'unclassified'
        );

        if (!$phrase) {
            return new WP_Error('isc_missing_phrase', 'phrase is required.', ['status' => 400]);
        }

        if (!$space_id && $space_uid) {
            $spaces = self::table(self::SPACE_TABLE);
            $space_id = intval($wpdb->get_var(
                $wpdb->prepare("SELECT id FROM $spaces WHERE space_uid = %s", $space_uid)
            ));
        }

        if (!$space_id) {
            self::ensure_default_space();
            $spaces = self::table(self::SPACE_TABLE);
            $space_id = intval($wpdb->get_var(
                $wpdb->prepare("SELECT id FROM $spaces WHERE space_uid = %s", 'default_cloud_phrases')
            ));
        }

        $user = wp_get_current_user();
        $now = current_time('mysql');

        $ok = $wpdb->insert(self::table(self::PHRASE_TABLE), [
            'space_id' => $space_id,
            'phrase' => $phrase,
            'context' => $context,
            'source' => $source,
            'owner_user_id' => $user->ID,
            'owner_email' => $user->user_email,
            'cluster_id' => null,
            'sr_type' => $sr_type,
            'execution_potential' => $execution_potential,
            'isc_role' => $isc_role,
            'status' => 'new',
            'admin_note' => null,
            'created_at' => $now,
            'updated_at' => $now
        ], ['%d','%s','%s','%s','%d','%s','%d','%s','%s','%s','%s','%s','%s','%s']);

        if (!$ok) {
            return new WP_Error('isc_db_error', 'Could not create phrase.', ['status' => 500]);
        }

        return [
            'status' => 'ok',
            'phrase' => [
                'id' => intval($wpdb->insert_id),
                'space_id' => $space_id,
                'phrase' => $phrase,
                'sr_type' => $sr_type,
                'execution_potential' => $execution_potential,
                'isc_role' => $isc_role
            ]
        ];
    }

    public static function update_phrase($request) {
        global $wpdb;

        $phrase_id = intval($request['id']);

        $sr_type = self::clean_enum(
            $request->get_param('sr_type'),
            self::sr_type_options(),
            'unclassified'
        );

        $execution_potential = self::clean_enum(
            $request->get_param('execution_potential'),
            self::execution_potential_options(),
            'unknown'
        );

        $isc_role = self::clean_enum(
            $request->get_param('isc_role'),
            self::isc_role_options(),
            'unclassified'
        );

        $status = sanitize_key($request->get_param('status') ?: 'new');
        $admin_note = sanitize_textarea_field($request->get_param('admin_note') ?: '');
        $normalized_id = sanitize_key($request->get_param('normalized_id') ?: '');
        $normalized_phrase = sanitize_text_field($request->get_param('normalized_phrase') ?: '');
        $cluster_description = sanitize_textarea_field($request->get_param('cluster_description') ?: '');
        $now = current_time('mysql');

        $cluster_id = null;

        if ($normalized_id && $normalized_phrase) {
            $clusters = self::table(self::CLUSTER_TABLE);

            $existing = $wpdb->get_row(
                $wpdb->prepare("SELECT * FROM $clusters WHERE normalized_id = %s", $normalized_id)
            );

            if ($existing) {
                $cluster_id = intval($existing->id);
                $wpdb->update($clusters, [
                    'normalized_phrase' => $normalized_phrase,
                    'description' => $cluster_description ?: $existing->description,
                    'updated_at' => $now
                ], ['id' => $cluster_id], ['%s','%s','%s'], ['%d']);
            } else {
                $wpdb->insert($clusters, [
                    'normalized_id' => $normalized_id,
                    'normalized_phrase' => $normalized_phrase,
                    'description' => $cluster_description,
                    'created_by' => get_current_user_id(),
                    'created_at' => $now,
                    'updated_at' => $now
                ], ['%s','%s','%s','%d','%s','%s']);
                $cluster_id = intval($wpdb->insert_id);
            }

            $status = 'normalized';
        }

        $ok = $wpdb->update(self::table(self::PHRASE_TABLE), [
            'cluster_id' => $cluster_id,
            'sr_type' => $sr_type,
            'execution_potential' => $execution_potential,
            'isc_role' => $isc_role,
            'status' => $status,
            'admin_note' => $admin_note,
            'updated_at' => $now
        ], ['id' => $phrase_id], ['%d','%s','%s','%s','%s','%s','%s'], ['%d']);

        if ($ok === false) {
            return new WP_Error('isc_db_error', 'Could not update phrase.', ['status' => 500]);
        }

        return ['status' => 'ok', 'phrase_id' => $phrase_id];
    }

    public static function export_space($request) {
        global $wpdb;

        $space_uid = sanitize_key($request->get_param('space_uid'));
        if (!$space_uid) {
            return new WP_Error('isc_missing_space_uid', 'space_uid is required.', ['status' => 400]);
        }

        $spaces = self::table(self::SPACE_TABLE);
        $phrases = self::table(self::PHRASE_TABLE);
        $clusters = self::table(self::CLUSTER_TABLE);

        $space = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $spaces WHERE space_uid = %s", $space_uid),
            ARRAY_A
        );

        if (!$space) {
            return new WP_Error('isc_space_not_found', 'Space not found.', ['status' => 404]);
        }

        $rows = $wpdb->get_results($wpdb->prepare("
            SELECT
                p.id, p.phrase, p.context, p.source,
                p.owner_email,
                p.sr_type, p.execution_potential,
                p.isc_role, p.status,
                c.normalized_id, c.normalized_phrase,
                c.description AS cluster_description,
                p.created_at, p.updated_at
            FROM $phrases p
            LEFT JOIN $clusters c ON p.cluster_id = c.id
            WHERE p.space_id = %d
            ORDER BY p.created_at ASC
        ", intval($space['id'])), ARRAY_A);

        $seed = [
            'intentions' => [],
            'design_nodes' => [],
            'objects' => [],
            'pulses' => [],
            'signals' => [],
            'cpux' => [],
            'constraints' => [],
            'services' => [],
            'resources' => [],
            'decision_phrases' => []
        ];

        foreach ($rows as $row) {
            if ($row['isc_role'] === 'intention') $seed['intentions'][] = $row;
            if ($row['isc_role'] === 'design_node') $seed['design_nodes'][] = $row;
            if ($row['isc_role'] === 'object') $seed['objects'][] = $row;
            if ($row['isc_role'] === 'pulse') $seed['pulses'][] = $row;
            if ($row['isc_role'] === 'signal') $seed['signals'][] = $row;
            if ($row['isc_role'] === 'cpux') $seed['cpux'][] = $row;
            if ($row['isc_role'] === 'constraint') $seed['constraints'][] = $row;
            if ($row['isc_role'] === 'service') $seed['services'][] = $row;
            if ($row['isc_role'] === 'resource') $seed['resources'][] = $row;
            if ($row['isc_role'] === 'decision_phrase') $seed['decision_phrases'][] = $row;
        }

        return [
            'schema' => 'intentix.isc.phrase_space.v2',
            'space' => $space,
            'sr_model' => [
                'sr_types' => self::sr_type_options(),
                'execution_potentials' => self::execution_potential_options()
            ],
            'phrases' => $rows,
            'intention_space_seed' => $seed
        ];
    }
}

ISC_Phrase_API::init();
