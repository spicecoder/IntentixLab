# ISC Phrase API v0.2

API-only WordPress plugin for Intention Space phrase collection.

## New in v0.2

Adds two Situational Reality fields:

- `sr_type`
- `execution_potential`

This keeps phrase collection open and avoids forcing early mapping into Intention Space runtime primitives.

## New endpoint

```http
GET /wp-json/isc/v1/schema
```

Returns allowed `sr_type`, `execution_potential`, and `isc_role` values.

## Example create phrase

```http
POST /wp-json/isc/v1/phrases
Content-Type: application/json

{
  "space_uid": "gcp_architect_field_language_001",
  "phrase": "make it survive a zone failure",
  "context": "Architect is thinking about resilience",
  "source": "intentixlab-static-site",
  "sr_type": "constraint_phrase",
  "execution_potential": "field_condition",
  "isc_role": "unclassified"
}
```

## Principle

A phrase is first classified at the Situational Reality layer, then optionally mapped to Intention Space runtime roles.

```text
Phrase
  -> sr_type
  -> execution_potential
  -> normalized cluster
  -> optional IS role
  -> CPUX design seed
```

## Install / upgrade

Upload and activate `isc-phrase-api-v2.zip`.

If v0.1 is already installed, deactivate/delete it first, then upload v0.2. Existing tables/data are preserved. The plugin adds missing columns during activation/load.
