IntentixLab Contact API plugin. Upload zip to WordPress, activate, then test /wp-json/intentix/v1/health.
