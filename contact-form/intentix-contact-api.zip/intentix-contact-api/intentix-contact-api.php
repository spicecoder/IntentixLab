<?php
/**
 * Plugin Name: IntentixLab Contact API
 * Description: API-first contact form backend for IntentixLab collaboration messages. Stores messages in MySQL and optionally sends email notification.
 * Version: 0.1.0
 * Author: IntentixLab
 */

if (!defined('ABSPATH')) exit;

class Intentix_Contact_API {
    const TABLE = 'intentix_contact_messages';
    const OPTION_NOTIFY_EMAIL = 'intentix_contact_notify_email';

    public static function init() {
        register_activation_hook(__FILE__, [__CLASS__, 'activate']);
        add_action('rest_api_init', [__CLASS__, 'register_routes']);
        add_action('rest_api_init', [__CLASS__, 'cors_headers'], 15);
        add_action('admin_menu', [__CLASS__, 'admin_menu']);
    }

    private static function table() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE;
    }

    public static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $table = self::table();
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(190) NOT NULL,
            email VARCHAR(190) NOT NULL,
            organization VARCHAR(190) NULL,
            interest VARCHAR(190) NULL,
            message TEXT NOT NULL,
            source_url TEXT NULL,
            ip_address VARCHAR(80) NULL,
            user_agent TEXT NULL,
            status VARCHAR(40) NOT NULL DEFAULT 'new',
            email_sent TINYINT(1) NOT NULL DEFAULT 0,
            admin_note TEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY email (email),
            KEY status (status),
            KEY created_at (created_at)
        ) $charset;";

        dbDelta($sql);

        if (!get_option(self::OPTION_NOTIFY_EMAIL)) {
            update_option(self::OPTION_NOTIFY_EMAIL, get_option('admin_email'));
        }
    }

    public static function cors_headers() {
        add_filter('rest_pre_serve_request', function ($served) {
            $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
            $allowed = [
                'https://intentixlab.com',
                'https://www.intentixlab.com',
                'https://keybytesystems.com',
                'https://www.keybytesystems.com'
            ];

            if (in_array($origin, $allowed, true)) {
                header('Access-Control-Allow-Origin: ' . esc_url_raw($origin));
                header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
                header('Access-Control-Allow-Headers: Content-Type');
            }
            return $served;
        }, 10, 1);
    }

    public static function register_routes() {
        register_rest_route('intentix/v1', '/health', [
            'methods' => 'GET',
            'callback' => function () {
                return ['status' => 'ok', 'plugin' => 'IntentixLab Contact API', 'version' => '0.1.0'];
            },
            'permission_callback' => '__return_true'
        ]);

        register_rest_route('intentix/v1', '/contact', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'submit_contact'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route('intentix/v1', '/messages', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_messages'],
            'permission_callback' => function () { return current_user_can('manage_options'); }
        ]);
    }

    private static function client_ip() {
        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $key) {
            if (!empty($_SERVER[$key])) {
                $raw = sanitize_text_field(wp_unslash($_SERVER[$key]));
                return trim(explode(',', $raw)[0]);
            }
        }
        return '';
    }

    private static function rate_limited($ip) {
        if (!$ip) return false;
        $key = 'intentix_contact_rate_' . md5($ip);
        $count = intval(get_transient($key));
        if ($count >= 5) return true;
        set_transient($key, $count + 1, 10 * MINUTE_IN_SECONDS);
        return false;
    }

    public static function submit_contact(WP_REST_Request $request) {
        global $wpdb;

        $ip = self::client_ip();
        if (self::rate_limited($ip)) {
            return new WP_Error('intentix_rate_limited', 'Too many submissions. Please try again later.', ['status' => 429]);
        }

        // Honeypot. Static form must leave this blank.
        if (sanitize_text_field($request->get_param('website') ?: '') !== '') {
            return ['status' => 'ok', 'message' => 'Thank you.'];
        }

        $name = sanitize_text_field($request->get_param('name') ?: '');
        $email = sanitize_email($request->get_param('email') ?: '');
        $organization = sanitize_text_field($request->get_param('organization') ?: '');
        $interest = sanitize_text_field($request->get_param('interest') ?: '');
        $message = sanitize_textarea_field($request->get_param('message') ?: '');
        $source_url = esc_url_raw($request->get_param('source_url') ?: '');

        if (!$name || !$email || !$message) {
            return new WP_Error('intentix_missing_fields', 'Name, email, and message are required.', ['status' => 400]);
        }

        if (!is_email($email)) {
            return new WP_Error('intentix_invalid_email', 'Please provide a valid email address.', ['status' => 400]);
        }

        $now = current_time('mysql');
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_textarea_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '';

        $ok = $wpdb->insert(self::table(), [
            'name' => $name,
            'email' => $email,
            'organization' => $organization,
            'interest' => $interest,
            'message' => $message,
            'source_url' => $source_url,
            'ip_address' => $ip,
            'user_agent' => $ua,
            'status' => 'new',
            'email_sent' => 0,
            'admin_note' => '',
            'created_at' => $now,
            'updated_at' => $now
        ], ['%s','%s','%s','%s','%s','%s','%s','%s','%s','%d','%s','%s','%s']);

        if (!$ok) {
            return new WP_Error('intentix_db_error', 'Could not save message.', ['status' => 500]);
        }

        $id = intval($wpdb->insert_id);
        $email_sent = self::send_notification($id, compact('name','email','organization','interest','message','source_url','ip'));

        if ($email_sent) {
            $wpdb->update(self::table(), ['email_sent' => 1, 'updated_at' => current_time('mysql')], ['id' => $id], ['%d','%s'], ['%d']);
        }

        return ['status' => 'ok', 'message' => 'Thank you. Your message has been received.', 'id' => $id, 'email_sent' => (bool)$email_sent];
    }

    private static function send_notification($id, $data) {
        $to = get_option(self::OPTION_NOTIFY_EMAIL, get_option('admin_email'));
        if (!$to || !is_email($to)) return false;

        $subject = '[IntentixLab Collaboration] New message #' . $id;
        $body = "New IntentixLab collaboration message\n\n";
        $body .= "Message ID: $id\n";
        $body .= "Name: {$data['name']}\n";
        $body .= "Email: {$data['email']}\n";
        $body .= "Organization / GitHub: {$data['organization']}\n";
        $body .= "Interest: {$data['interest']}\n";
        $body .= "Source URL: {$data['source_url']}\n";
        $body .= "IP: {$data['ip']}\n\n";
        $body .= "Message:\n{$data['message']}\n";

        $headers = [
            'Content-Type: text/plain; charset=UTF-8',
            'Reply-To: ' . $data['name'] . ' <' . $data['email'] . '>'
        ];

        return wp_mail($to, $subject, $body, $headers);
    }

    public static function get_messages(WP_REST_Request $request) {
        global $wpdb;
        $limit = max(1, min(intval($request->get_param('limit') ?: 100), 500));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, name, email, organization, interest, message, source_url, status, email_sent, created_at
             FROM " . self::table() . " ORDER BY created_at DESC LIMIT %d",
            $limit
        ), ARRAY_A);
        return ['messages' => $rows];
    }

    public static function admin_menu() {
        add_menu_page('Intentix Contact', 'Intentix Contact', 'manage_options', 'intentix-contact-api', [__CLASS__, 'admin_page'], 'dashicons-email-alt', 27);
    }

    public static function admin_page() {
        if (!current_user_can('manage_options')) wp_die('Not allowed.');
        global $wpdb;

        if (isset($_POST['intentix_contact_settings_nonce']) && wp_verify_nonce($_POST['intentix_contact_settings_nonce'], 'intentix_contact_settings')) {
            $notify_email = sanitize_email($_POST['notify_email'] ?? '');
            if ($notify_email && is_email($notify_email)) {
                update_option(self::OPTION_NOTIFY_EMAIL, $notify_email);
                echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
            }
        }

        $notify_email = get_option(self::OPTION_NOTIFY_EMAIL, get_option('admin_email'));
        $rows = $wpdb->get_results("SELECT * FROM " . self::table() . " ORDER BY created_at DESC LIMIT 100");
        ?>
        <div class="wrap">
            <h1>IntentixLab Contact API</h1>
            <h2>Settings</h2>
            <form method="post">
                <?php wp_nonce_field('intentix_contact_settings', 'intentix_contact_settings_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="notify_email">Notification email</label></th>
                        <td>
                            <input name="notify_email" id="notify_email" type="email" class="regular-text" value="<?php echo esc_attr($notify_email); ?>" />
                            <p class="description">Messages are stored first; email notification is attempted after storage.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Save Settings'); ?>
            </form>

            <h2>Recent Messages</h2>
            <table class="widefat striped">
                <thead><tr><th>ID</th><th>Created</th><th>Name</th><th>Email</th><th>Interest</th><th>Email Sent</th><th>Message</th></tr></thead>
                <tbody>
                <?php foreach ($rows as $row): ?>
                    <tr>
                        <td><?php echo intval($row->id); ?></td>
                        <td><?php echo esc_html($row->created_at); ?></td>
                        <td><?php echo esc_html($row->name); ?></td>
                        <td><?php echo esc_html($row->email); ?></td>
                        <td><?php echo esc_html($row->interest); ?></td>
                        <td><?php echo intval($row->email_sent) ? 'yes' : 'no'; ?></td>
                        <td><?php echo esc_html(wp_trim_words($row->message, 24)); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <h2>API endpoints</h2>
            <pre>GET  /wp-json/intentix/v1/health
POST /wp-json/intentix/v1/contact
GET  /wp-json/intentix/v1/messages   (admin only)</pre>
        </div>
        <?php
    }
}

Intentix_Contact_API::init();
